﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.DoWhileRadioButton1 = New System.Windows.Forms.RadioButton()
        Me.DoUntilRadioButton2 = New System.Windows.Forms.RadioButton()
        Me.ForRadioButton3 = New System.Windows.Forms.RadioButton()
        Me.WhileRadioButton4 = New System.Windows.Forms.RadioButton()
        Me.LoopsGroupBox1 = New System.Windows.Forms.GroupBox()
        Me.BeginTextBox1 = New System.Windows.Forms.TextBox()
        Me.StepTextBox3 = New System.Windows.Forms.TextBox()
        Me.EndTextBox4 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ExecuteButton1 = New System.Windows.Forms.Button()
        Me.SyntaxTextBox2 = New System.Windows.Forms.TextBox()
        Me.ResultsTextBox5 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.LoopsGroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DoWhileRadioButton1
        '
        Me.DoWhileRadioButton1.AutoSize = True
        Me.DoWhileRadioButton1.Location = New System.Drawing.Point(6, 19)
        Me.DoWhileRadioButton1.Name = "DoWhileRadioButton1"
        Me.DoWhileRadioButton1.Size = New System.Drawing.Size(165, 17)
        Me.DoWhileRadioButton1.TabIndex = 0
        Me.DoWhileRadioButton1.TabStop = True
        Me.DoWhileRadioButton1.Text = "Do           loop while condition"
        Me.DoWhileRadioButton1.UseVisualStyleBackColor = True
        '
        'DoUntilRadioButton2
        '
        Me.DoUntilRadioButton2.AutoSize = True
        Me.DoUntilRadioButton2.Location = New System.Drawing.Point(6, 42)
        Me.DoUntilRadioButton2.Name = "DoUntilRadioButton2"
        Me.DoUntilRadioButton2.Size = New System.Drawing.Size(105, 17)
        Me.DoUntilRadioButton2.TabIndex = 1
        Me.DoUntilRadioButton2.TabStop = True
        Me.DoUntilRadioButton2.Text = "Do      Loop Until"
        Me.DoUntilRadioButton2.UseVisualStyleBackColor = True
        '
        'ForRadioButton3
        '
        Me.ForRadioButton3.AutoSize = True
        Me.ForRadioButton3.Location = New System.Drawing.Point(6, 65)
        Me.ForRadioButton3.Name = "ForRadioButton3"
        Me.ForRadioButton3.Size = New System.Drawing.Size(183, 17)
        Me.ForRadioButton3.TabIndex = 2
        Me.ForRadioButton3.TabStop = True
        Me.ForRadioButton3.Text = "for i = beg to end step s.        next"
        Me.ForRadioButton3.UseVisualStyleBackColor = True
        '
        'WhileRadioButton4
        '
        Me.WhileRadioButton4.AutoSize = True
        Me.WhileRadioButton4.Location = New System.Drawing.Point(6, 88)
        Me.WhileRadioButton4.Name = "WhileRadioButton4"
        Me.WhileRadioButton4.Size = New System.Drawing.Size(156, 17)
        Me.WhileRadioButton4.TabIndex = 3
        Me.WhileRadioButton4.TabStop = True
        Me.WhileRadioButton4.Text = "while condtion      end while"
        Me.WhileRadioButton4.UseVisualStyleBackColor = True
        '
        'LoopsGroupBox1
        '
        Me.LoopsGroupBox1.Controls.Add(Me.WhileRadioButton4)
        Me.LoopsGroupBox1.Controls.Add(Me.DoWhileRadioButton1)
        Me.LoopsGroupBox1.Controls.Add(Me.ForRadioButton3)
        Me.LoopsGroupBox1.Controls.Add(Me.DoUntilRadioButton2)
        Me.LoopsGroupBox1.ForeColor = System.Drawing.Color.Magenta
        Me.LoopsGroupBox1.Location = New System.Drawing.Point(30, 22)
        Me.LoopsGroupBox1.Name = "LoopsGroupBox1"
        Me.LoopsGroupBox1.Size = New System.Drawing.Size(222, 128)
        Me.LoopsGroupBox1.TabIndex = 4
        Me.LoopsGroupBox1.TabStop = False
        Me.LoopsGroupBox1.Text = "Loops Types"
        '
        'BeginTextBox1
        '
        Me.BeginTextBox1.ForeColor = System.Drawing.Color.Red
        Me.BeginTextBox1.Location = New System.Drawing.Point(347, 38)
        Me.BeginTextBox1.Name = "BeginTextBox1"
        Me.BeginTextBox1.Size = New System.Drawing.Size(100, 20)
        Me.BeginTextBox1.TabIndex = 5
        Me.BeginTextBox1.Text = "0"
        '
        'StepTextBox3
        '
        Me.StepTextBox3.ForeColor = System.Drawing.Color.Crimson
        Me.StepTextBox3.Location = New System.Drawing.Point(347, 107)
        Me.StepTextBox3.Name = "StepTextBox3"
        Me.StepTextBox3.Size = New System.Drawing.Size(100, 20)
        Me.StepTextBox3.TabIndex = 7
        Me.StepTextBox3.Text = "1"
        '
        'EndTextBox4
        '
        Me.EndTextBox4.ForeColor = System.Drawing.Color.RoyalBlue
        Me.EndTextBox4.Location = New System.Drawing.Point(347, 73)
        Me.EndTextBox4.Name = "EndTextBox4"
        Me.EndTextBox4.Size = New System.Drawing.Size(100, 20)
        Me.EndTextBox4.TabIndex = 8
        Me.EndTextBox4.Text = "47"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(295, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(34, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Begin"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(295, 76)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(26, 13)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "End"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(295, 107)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Step"
        '
        'ExecuteButton1
        '
        Me.ExecuteButton1.BackColor = System.Drawing.Color.Cyan
        Me.ExecuteButton1.Location = New System.Drawing.Point(556, 41)
        Me.ExecuteButton1.Name = "ExecuteButton1"
        Me.ExecuteButton1.Size = New System.Drawing.Size(146, 86)
        Me.ExecuteButton1.TabIndex = 12
        Me.ExecuteButton1.Text = "Execute"
        Me.ExecuteButton1.UseVisualStyleBackColor = False
        '
        'SyntaxTextBox2
        '
        Me.SyntaxTextBox2.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SyntaxTextBox2.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SyntaxTextBox2.Location = New System.Drawing.Point(48, 176)
        Me.SyntaxTextBox2.Multiline = True
        Me.SyntaxTextBox2.Name = "SyntaxTextBox2"
        Me.SyntaxTextBox2.Size = New System.Drawing.Size(308, 241)
        Me.SyntaxTextBox2.TabIndex = 13
        '
        'ResultsTextBox5
        '
        Me.ResultsTextBox5.BackColor = System.Drawing.SystemColors.MenuText
        Me.ResultsTextBox5.ForeColor = System.Drawing.Color.Lime
        Me.ResultsTextBox5.Location = New System.Drawing.Point(383, 176)
        Me.ResultsTextBox5.Multiline = True
        Me.ResultsTextBox5.Name = "ResultsTextBox5"
        Me.ResultsTextBox5.Size = New System.Drawing.Size(393, 241)
        Me.ResultsTextBox5.TabIndex = 14
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(48, 157)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 13)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Loop Syntax"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(383, 157)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 13)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "ExecuteResults"
        '
        'form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.ResultsTextBox5)
        Me.Controls.Add(Me.SyntaxTextBox2)
        Me.Controls.Add(Me.ExecuteButton1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.EndTextBox4)
        Me.Controls.Add(Me.StepTextBox3)
        Me.Controls.Add(Me.BeginTextBox1)
        Me.Controls.Add(Me.LoopsGroupBox1)
        Me.Name = "form1"
        Me.Text = "Form1"
        Me.LoopsGroupBox1.ResumeLayout(False)
        Me.LoopsGroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DoWhileRadioButton1 As RadioButton
    Friend WithEvents DoUntilRadioButton2 As RadioButton
    Friend WithEvents ForRadioButton3 As RadioButton
    Friend WithEvents WhileRadioButton4 As RadioButton
    Friend WithEvents LoopsGroupBox1 As GroupBox
    Friend WithEvents BeginTextBox1 As TextBox
    Friend WithEvents StepTextBox3 As TextBox
    Friend WithEvents EndTextBox4 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents ExecuteButton1 As Button
    Friend WithEvents SyntaxTextBox2 As TextBox
    Friend WithEvents ResultsTextBox5 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label




End Class
