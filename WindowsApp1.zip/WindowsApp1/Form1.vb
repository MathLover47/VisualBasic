﻿Class form1
    Private Sub BeginTextBox1_Leave(sender As Object, e As EventArgs) Handles BeginTextBox1.Leave
        If Not IsNumeric(BeginTextBox1.Text) Then
            BeginTextBox1.Text = 0
        End If
    End Sub

    Private Sub ExecuteButton1_Click(sender As Object, e As EventArgs) Handles ExecuteButton1.Click
        Dim result01, result02 As String
        Dim loop01 As String
        Dim beginner01 As Double = BeginTextBox1.Text
        Dim step01 As Double = StepTextBox3.Text
        Dim end01 As Double = EndTextBox4.Text
        result01 = ""
        If beginner01 < end01 And step01 > 0 Then
            If DoWhileRadioButton1.Checked Then
                Do
                    result01 += beginner01.ToString + ","
                    beginner01 += step01

                Loop While beginner01 <= end01
                result02 = """ Do
                result01 += begin + ','
                begin += {0}

            Loop While begin <= {1} """


            ElseIf DoUntilRadioButton2.Checked Then
                Do
                    result01 += beginner01.ToString + ","
                    beginner01 += step01

                Loop Until beginner01 > end01
                result02 = """ Do
                result01 += begin + ','
                begin += {0}

            Loop Until begin > {1} """

            ElseIf ForRadioButton3.Checked Then
                For i As Integer = beginner01 To end01 Step step01
                    result01 += i.ToString + ","
                Next
                result02 = """ For i As Integer = begin To {1} Step {0}
                result01 += i + ','
            Next"""

            ElseIf WhileRadioButton4.Checked Then
                While beginner01 <= end01
                    result01 += beginner01.ToString + ","
                    beginner01 += step01
                End While
                result02 = """ While begin <= {1}
                result01 += begin + ','
                begin += {0}
            End While"""

            End If
        ElseIf beginner01 > end01 And step01 < 0 Then
            If DoWhileRadioButton1.Checked Then
                Do
                    result01 += beginner01.ToString + ","
                    beginner01 += step01

                Loop While beginner01 >= end01
                result02 = """ Do
                result01 += begin + ','
                begin += {0}

            Loop While begin >= {1} """


            ElseIf DoUntilRadioButton2.Checked Then
                Do
                    result01 += beginner01.ToString + ","
                    beginner01 += step01

                Loop Until beginner01 >= end01
                result02 = """ Do
                result01 += begin + ','
                begin += {0}

            Loop Until begin < {1} """

            ElseIf ForRadioButton3.Checked Then
                For i As Integer = beginner01 To end01 Step step01
                    result01 += i.ToString + ","
                Next
                result02 = """ For i As Integer = begin To {1} Step {0}
                result01 += i + ','
            Next"""

            ElseIf WhileRadioButton4.Checked Then
                While beginner01 >= end01
                    result01 += beginner01.ToString + ","
                    beginner01 += step01
                End While
                result02 = """ While begin >= {1}
                result01 += begin + ','
                begin += {0}
            End While"""

            End If
        Else MessageBox.Show("if begin less than end step should be positive\n else if begin
             more than end step should be negative", "Invalid")
            result01 = ""
            result02 = ""
        End If
        ResultsTextBox5.Text = result01
        SyntaxTextBox2.Text = String.Format(result02, step01, end01)
    End Sub

    Private Sub EndTextBox4_Leave(sender As Object, e As EventArgs) Handles EndTextBox4.Leave
        If Not IsNumeric(EndTextBox4.Text) Then
            EndTextBox4.Text = 47
        End If
    End Sub

    Private Sub StepTextBox3_Leave(sender As Object, e As EventArgs) Handles StepTextBox3.Leave
        If Not IsNumeric(StepTextBox3.Text) Then
            StepTextBox3.Text = 1
        End If
    End Sub

    Private Sub DoWhileRadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles DoWhileRadioButton1.CheckedChanged

    End Sub

    Private Sub LoopsGroupBox1_Enter(sender As Object, e As EventArgs) Handles LoopsGroupBox1.Enter

    End Sub
End Class